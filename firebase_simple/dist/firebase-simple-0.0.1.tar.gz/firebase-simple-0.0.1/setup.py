from setuptools import setup, find_packages

setup(
    name="firebase-simple",
    version="0.0.1",
    description="A secondary API for Firebase Realtime Database",
    long_description=open("README.md").read(),
    url="",
    author="Morgan West",
    author_email="morganzaque@hotmail.co.uk",
    license="PD",
    packages=find_packages(),
    classifiers=[
        "Programming Language :: Python :: 3",
        "License :: OSI Approved :: MIT License",
        "Operating System :: OS Independent",
    ],
    python_requires='>=3.6',
    install_requires=['firebase_admin']
)